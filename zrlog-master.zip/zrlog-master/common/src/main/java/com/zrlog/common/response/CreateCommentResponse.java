package com.zrlog.common.response;

public class CreateCommentResponse extends StandardResponse {

    private String alias;

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
}
