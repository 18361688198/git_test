package com.zrlog.common.response;

public class LoginResponse extends StandardResponse {

}
